import streamlit as st

# Define the page contents in functions
def home_page():
    st.title('首页')
    st.write('这是首页。')

def page2():
    st.title('页面 2')
    st.write('这是页面 2。')

def page3():
    st.title('页面 3')
    st.write('这是页面 3。')

# The main app
def main():
    # Simple navigation using the sidebar
    st.sidebar.title('导航')
    choice = st.sidebar.radio('去哪个页面?', ('首页', '页面 2', '页面 3'))

    # Main area
    if choice == '首页':
        home_page()
    elif choice == '页面 2':
        page2()
    elif choice == '页面 3':
        page3()

if __name__ == "__main__":
    main()